export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export interface Database {
  public: {
    Tables: {
      services: {
        Row: {
          id: string;
          name: string;
          description: string | null;
          duration_min: number;
          price: number;
          deposit: number;
          active: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          description?: string | null;
          duration_min: number;
          price: number;
          deposit?: number;
          active?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          description?: string | null;
          duration_min?: number;
          price?: number;
          deposit?: number;
          active?: boolean;
          created_at?: string;
        };
      };
      availability_rules: {
        Row: {
          id: string;
          day_of_week: number;
          start_time: string;
          end_time: string;
          active: boolean;
        };
        Insert: {
          id?: string;
          day_of_week: number;
          start_time: string;
          end_time: string;
          active?: boolean;
        };
        Update: {
          id?: string;
          day_of_week?: number;
          start_time?: string;
          end_time?: string;
          active?: boolean;
        };
      };
      bookings: {
        Row: {
          id: string;
          customer_id: string | null;
          service_id: string;
          dog_name: string;
          customer_name: string;
          customer_email: string;
          customer_phone: string | null;
          start_time: string;
          end_time: string;
          status: "pending" | "paid" | "completed" | "cancelled";
          stripe_session_id: string | null;
          amount_paid: number | null;
          notes: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          customer_id?: string | null;
          service_id: string;
          dog_name: string;
          customer_name: string;
          customer_email: string;
          customer_phone?: string | null;
          start_time: string;
          end_time: string;
          status?: "pending" | "paid" | "completed" | "cancelled";
          stripe_session_id?: string | null;
          amount_paid?: number | null;
          notes?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          customer_id?: string | null;
          service_id?: string;
          dog_name?: string;
          customer_name?: string;
          customer_email?: string;
          customer_phone?: string | null;
          start_time?: string;
          end_time?: string;
          status?: "pending" | "paid" | "completed" | "cancelled";
          stripe_session_id?: string | null;
          amount_paid?: number | null;
          notes?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      profiles: {
        Row: {
          id: string;
          full_name: string | null;
          phone: string | null;
          role: "customer" | "owner";
          created_at: string;
        };
        Insert: {
          id: string;
          full_name?: string | null;
          phone?: string | null;
          role?: "customer" | "owner";
          created_at?: string;
        };
        Update: {
          id?: string;
          full_name?: string | null;
          phone?: string | null;
          role?: "customer" | "owner";
          created_at?: string;
        };
      };
    };
  };
}

export type Service = Database["public"]["Tables"]["services"]["Row"];
export type Booking = Database["public"]["Tables"]["bookings"]["Row"];
export type Profile = Database["public"]["Tables"]["profiles"]["Row"];
export type AvailabilityRule = Database["public"]["Tables"]["availability_rules"]["Row"];
