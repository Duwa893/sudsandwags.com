import { createClient } from "@/lib/supabase/server";
import type { Profile } from "@/types/database";

export type Role = "customer" | "owner";

export async function getCurrentUser() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  return user;
}

export async function getCurrentProfile(): Promise<Profile | null> {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return null;

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single();

  return profile;
}

export async function requireAuth() {
  const user = await getCurrentUser();
  if (!user) {
    throw new Error("UNAUTHORIZED");
  }
  return user;
}

export async function requireRole(allowed: Role | Role[]) {
  const profile = await getCurrentProfile();
  if (!profile) {
    throw new Error("UNAUTHORIZED");
  }

  const roles = Array.isArray(allowed) ? allowed : [allowed];
  if (!roles.includes(profile.role as Role)) {
    throw new Error("FORBIDDEN");
  }

  return profile;
}

export async function isOwner(): Promise<boolean> {
  const profile = await getCurrentProfile();
  return profile?.role === "owner";
}
