"use client";

import Link from "next/link";
import { useAuth } from "@/lib/auth-client";

export default function Nav() {
  const { user, profile, isOwner, loading, signOut } = useAuth();

  return (
    <header className="border-b bg-white">
      <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-4">
        <Link href="/" className="text-xl font-bold tracking-tight text-amber-700">
          🐾 Paws & Polish
        </Link>

        <nav className="flex items-center gap-4 text-sm font-medium">
          <Link href="/book" className="text-gray-600 hover:text-amber-700">
            Book Now
          </Link>
          <Link href="/my-bookings" className="text-gray-600 hover:text-amber-700">
            My Bookings
          </Link>

          {isOwner && (
            <Link
              href="/dashboard"
              className="rounded-full bg-amber-100 px-3 py-1 text-amber-800 hover:bg-amber-200"
            >
              Owner Dashboard
            </Link>
          )}

          {!loading && (
            <>
              {user ? (
                <div className="flex items-center gap-3">
                  <span className="hidden text-xs text-gray-500 sm:inline">
                    {profile?.full_name || user.email}
                    {isOwner && (
                      <span className="ml-1 rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-semibold uppercase text-amber-800">
                        owner
                      </span>
                    )}
                  </span>
                  <button
                    onClick={signOut}
                    className="text-gray-500 hover:text-gray-800"
                  >
                    Sign out
                  </button>
                </div>
              ) : (
                <Link
                  href="/login"
                  className="rounded-full border px-3 py-1 text-gray-700 hover:bg-gray-50"
                >
                  Sign in
                </Link>
              )}
            </>
          )}
        </nav>
      </div>
    </header>
  );
}
