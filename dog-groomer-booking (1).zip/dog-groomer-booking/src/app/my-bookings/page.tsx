"use client";

import { useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { formatCurrency, formatDateTime } from "@/lib/utils";
import type { Booking, Service } from "@/types/database";
import Link from "next/link";

type BookingWithService = Booking & { services: Service | null };

export default function MyBookingsPage() {
  const supabase = createClient();
  const [bookings, setBookings] = useState<BookingWithService[]>([]);
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [cancellingId, setCancellingId] = useState<string | null>(null);

  async function loadByEmail(e?: React.FormEvent) {
    if (e) e.preventDefault();
    setLoading(true);
    setSearched(true);

    const { data } = await supabase
      .from("bookings")
      .select("*, services(*)")
      .eq("customer_email", email.trim().toLowerCase())
      .order("start_time", { ascending: false });

    setBookings((data as any) || []);
    setLoading(false);
  }

  function canCancel(booking: Booking): boolean {
    if (booking.status !== "pending" && booking.status !== "paid") return false;
    return new Date(booking.start_time) > new Date();
  }

  async function handleCancel(booking: BookingWithService) {
    const confirmed = window.confirm(
      `Cancel the appointment for ${booking.dog_name} on ${formatDateTime(booking.start_time)}?\n\nNote: Deposits are non-refundable.`
    );
    if (!confirmed) return;

    setCancellingId(booking.id);

    try {
      const res = await fetch("/api/bookings/cancel", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          bookingId: booking.id,
          email: email.trim(),
        }),
      });

      const json = await res.json();

      if (!res.ok) {
        alert(json.error || "Could not cancel booking");
        setCancellingId(null);
        return;
      }

      // Refresh list
      await loadByEmail();
    } catch {
      alert("Network error – please try again");
    } finally {
      setCancellingId(null);
    }
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-12">
      <h1 className="text-3xl font-bold">My Bookings</h1>
      <p className="mt-2 text-gray-600">
        Enter the email you used when booking to see and manage your appointments.
      </p>

      <form onSubmit={loadByEmail} className="mt-8 flex gap-3">
        <input
          type="email"
          required
          placeholder="you@example.com"
          className="flex-1 rounded-lg border px-4 py-2"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <button
          type="submit"
          disabled={loading}
          className="rounded-lg bg-amber-600 px-6 py-2 font-medium text-white hover:bg-amber-700 disabled:opacity-60"
        >
          {loading ? "Loading…" : "Look up"}
        </button>
      </form>

      {searched && (
        <div className="mt-10 space-y-4">
          {bookings.length === 0 ? (
            <p className="text-gray-500">No bookings found for that email.</p>
          ) : (
            bookings.map((b) => (
              <div
                key={b.id}
                className="rounded-xl border bg-white p-5 shadow-sm"
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <div className="font-semibold">
                      {b.services?.name || "Service"}
                    </div>
                    <div className="text-sm text-gray-600">
                      {b.dog_name} • {formatDateTime(b.start_time)}
                    </div>
                    <div className="mt-1 text-sm text-gray-500">
                      {b.customer_name}
                    </div>
                    {b.amount_paid != null && (
                      <div className="mt-1 text-sm text-gray-500">
                        Paid {formatCurrency(b.amount_paid)}
                      </div>
                    )}
                  </div>

                  <div className="flex flex-col items-end gap-2">
                    <span
                      className={`rounded-full px-3 py-1 text-xs font-medium capitalize ${
                        b.status === "paid"
                          ? "bg-green-100 text-green-800"
                          : b.status === "completed"
                          ? "bg-blue-100 text-blue-800"
                          : b.status === "cancelled"
                          ? "bg-red-100 text-red-800"
                          : "bg-yellow-100 text-yellow-800"
                      }`}
                    >
                      {b.status}
                    </span>

                    {canCancel(b) && (
                      <button
                        onClick={() => handleCancel(b)}
                        disabled={cancellingId === b.id}
                        className="text-sm font-medium text-red-600 hover:text-red-800 hover:underline disabled:opacity-50"
                      >
                        {cancellingId === b.id ? "Cancelling…" : "Cancel booking"}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      <p className="mt-12 text-center text-sm text-gray-500">
        Prefer a permanent account?{" "}
        <Link href="/login" className="text-amber-700 underline">
          Sign in with magic link
        </Link>
      </p>
    </div>
  );
}
