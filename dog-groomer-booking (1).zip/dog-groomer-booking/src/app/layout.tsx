import type { Metadata } from "next";
import "./globals.css";
import Nav from "@/components/Nav";

export const metadata: Metadata = {
  title: "Paws & Polish | Dog Grooming Bookings",
  description:
    "Book a grooming appointment for your dog. Easy online booking with secure deposit.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="min-h-screen antialiased">
        <Nav />
        <main>{children}</main>
        <footer className="mt-16 border-t py-8 text-center text-sm text-gray-500">
          © {new Date().getFullYear()} Paws & Polish Grooming. All rights reserved.
        </footer>
      </body>
    </html>
  );
}
