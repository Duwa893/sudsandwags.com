import Link from "next/link";

export default function HomePage() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-16">
      <section className="text-center">
        <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-5xl">
          Professional Dog Grooming
        </h1>
        <p className="mx-auto mt-4 max-w-2xl text-lg text-gray-600">
          Book a bath, full groom, or nail trim in minutes. Pay a small deposit online
          and we&apos;ll take care of the rest.
        </p>
        <div className="mt-8">
          <Link
            href="/book"
            className="inline-block rounded-full bg-amber-600 px-8 py-3 text-lg font-semibold text-white shadow-sm hover:bg-amber-700 transition"
          >
            Book an Appointment
          </Link>
        </div>
      </section>

      <section className="mt-20 grid gap-8 sm:grid-cols-3">
        <div className="rounded-2xl border bg-white p-6 shadow-sm">
          <div className="text-3xl">🛁</div>
          <h3 className="mt-3 font-semibold">Bath & Brush</h3>
          <p className="mt-1 text-sm text-gray-600">Gentle wash and thorough brushing.</p>
        </div>
        <div className="rounded-2xl border bg-white p-6 shadow-sm">
          <div className="text-3xl">✂️</div>
          <h3 className="mt-3 font-semibold">Full Groom</h3>
          <p className="mt-1 text-sm text-gray-600">Haircut, nails, ears — the works.</p>
        </div>
        <div className="rounded-2xl border bg-white p-6 shadow-sm">
          <div className="text-3xl">💅</div>
          <h3 className="mt-3 font-semibold">Nail Trim</h3>
          <p className="mt-1 text-sm text-gray-600">Quick and painless nail care.</p>
        </div>
      </section>
    </div>
  );
}
