import Link from "next/link";

export default function SuccessPage() {
  return (
    <div className="mx-auto max-w-lg px-4 py-24 text-center">
      <div className="text-6xl">🎉</div>
      <h1 className="mt-6 text-3xl font-bold">Booking Confirmed!</h1>
      <p className="mt-3 text-gray-600">
        Your deposit has been paid and your appointment is reserved.
        We&apos;ll send a reminder the day before.
      </p>
      <div className="mt-8 flex justify-center gap-4">
        <Link
          href="/my-bookings"
          className="rounded-full bg-amber-600 px-6 py-2.5 font-medium text-white hover:bg-amber-700"
        >
          View My Bookings
        </Link>
        <Link
          href="/"
          className="rounded-full border px-6 py-2.5 font-medium hover:bg-gray-50"
        >
          Home
        </Link>
      </div>
    </div>
  );
}
