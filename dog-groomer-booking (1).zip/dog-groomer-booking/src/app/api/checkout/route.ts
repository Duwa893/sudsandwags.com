import { NextRequest, NextResponse } from "next/server";
import { stripe } from "@/lib/stripe";
import { createAdminClient } from "@/lib/supabase/admin";

export async function POST(req: NextRequest) {
  try {
    const { bookingId, serviceName, deposit, customerEmail } = await req.json();

    if (!bookingId || !serviceName || !deposit) {
      return NextResponse.json({ error: "Missing fields" }, { status: 400 });
    }

    const origin = process.env.NEXT_PUBLIC_APP_URL || req.nextUrl.origin;

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      customer_email: customerEmail,
      line_items: [
        {
          price_data: {
            currency: "usd",
            product_data: {
              name: `Deposit – ${serviceName}`,
              description: "Non-refundable booking deposit",
            },
            unit_amount: deposit,
          },
          quantity: 1,
        },
      ],
      metadata: {
        booking_id: bookingId,
      },
      success_url: `${origin}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/book?cancelled=1`,
    });

    // Store session id on the booking
    const supabase = createAdminClient();
    await supabase
      .from("bookings")
      .update({ stripe_session_id: session.id })
      .eq("id", bookingId);

    return NextResponse.json({ url: session.url });
  } catch (err: any) {
    console.error(err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
