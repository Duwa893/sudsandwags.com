import { NextRequest, NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";

/**
 * Allow a customer to cancel their own upcoming booking
 * by providing booking ID + the email used at booking time.
 * Uses service role so it works even when the user is not logged in.
 */
export async function POST(req: NextRequest) {
  try {
    const { bookingId, email } = await req.json();

    if (!bookingId || !email) {
      return NextResponse.json(
        { error: "bookingId and email are required" },
        { status: 400 }
      );
    }

    const supabase = createAdminClient();

    // Fetch the booking first
    const { data: booking, error: fetchError } = await supabase
      .from("bookings")
      .select("*")
      .eq("id", bookingId)
      .single();

    if (fetchError || !booking) {
      return NextResponse.json({ error: "Booking not found" }, { status: 404 });
    }

    // Verify email matches
    if (booking.customer_email.toLowerCase() !== email.trim().toLowerCase()) {
      return NextResponse.json({ error: "Email does not match this booking" }, { status: 403 });
    }

    // Only allow cancel of upcoming pending/paid bookings
    if (booking.status !== "pending" && booking.status !== "paid") {
      return NextResponse.json(
        { error: `Cannot cancel a booking with status "${booking.status}"` },
        { status: 400 }
      );
    }

    if (new Date(booking.start_time) <= new Date()) {
      return NextResponse.json(
        { error: "Cannot cancel a booking that has already started" },
        { status: 400 }
      );
    }

    // Perform the cancel
    const { error: updateError } = await supabase
      .from("bookings")
      .update({ status: "cancelled" })
      .eq("id", bookingId);

    if (updateError) {
      return NextResponse.json({ error: updateError.message }, { status: 500 });
    }

    return NextResponse.json({ success: true });
  } catch (err: any) {
    console.error(err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
