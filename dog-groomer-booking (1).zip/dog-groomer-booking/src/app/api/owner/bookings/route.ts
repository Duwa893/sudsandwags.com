import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { requireRole } from "@/lib/auth";

/**
 * Example of a protected API route using RBAC.
 * Only users with role = 'owner' can call this.
 */
export async function GET() {
  try {
    // Throws if not logged in or not an owner
    await requireRole("owner");

    const supabase = await createClient();
    const { data, error } = await supabase
      .from("bookings")
      .select("*, services(*)")
      .order("start_time", { ascending: true });

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ bookings: data });
  } catch (err: any) {
    if (err.message === "UNAUTHORIZED") {
      return NextResponse.json({ error: "You must be signed in" }, { status: 401 });
    }
    if (err.message === "FORBIDDEN") {
      return NextResponse.json({ error: "Owner access required" }, { status: 403 });
    }
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
