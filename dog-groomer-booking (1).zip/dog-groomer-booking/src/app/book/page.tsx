"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { formatCurrency, formatDateTime } from "@/lib/utils";
import type { Service } from "@/types/database";
import { addDays, format, setHours, setMinutes, isBefore, startOfDay } from "date-fns";

type Slot = { start: string; end: string; label: string };

export default function BookPage() {
  const supabase = createClient();
  const [services, setServices] = useState<Service[]>([]);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [slots, setSlots] = useState<Slot[]>([]);
  const [selectedSlot, setSelectedSlot] = useState<Slot | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({
    customer_name: "",
    customer_email: "",
    customer_phone: "",
    dog_name: "",
  });

  useEffect(() => {
    async function load() {
      const { data } = await supabase
        .from("services")
        .select("*")
        .eq("active", true)
        .order("price");
      setServices(data || []);
      setLoading(false);
    }
    load();
  }, []);

  useEffect(() => {
    if (!selectedService) {
      setSlots([]);
      return;
    }
    generateSlots(selectedService);
  }, [selectedService]);

  async function generateSlots(service: Service) {
    // Simple slot generation: next 14 days, based on availability_rules + existing bookings
    const { data: rules } = await supabase
      .from("availability_rules")
      .select("*")
      .eq("active", true);

    const { data: existing } = await supabase
      .from("bookings")
      .select("start_time, end_time")
      .in("status", ["pending", "paid", "completed"])
      .gte("start_time", new Date().toISOString());

    const booked = new Set(
      (existing || []).map((b) => new Date(b.start_time).toISOString())
    );

    const result: Slot[] = [];
    const now = new Date();

    for (let d = 0; d < 14; d++) {
      const day = addDays(startOfDay(now), d);
      const dow = day.getDay();
      const rule = (rules || []).find((r) => r.day_of_week === dow);
      if (!rule) continue;

      const [startH, startM] = rule.start_time.split(":").map(Number);
      const [endH, endM] = rule.end_time.split(":").map(Number);

      let cursor = setMinutes(setHours(day, startH), startM);
      const end = setMinutes(setHours(day, endH), endM);

      while (isBefore(cursor, end)) {
        const slotEnd = new Date(cursor.getTime() + service.duration_min * 60 * 1000);
        if (isBefore(slotEnd, end) || slotEnd.getTime() === end.getTime()) {
          const iso = cursor.toISOString();
          if (!booked.has(iso) && isBefore(now, cursor)) {
            result.push({
              start: iso,
              end: slotEnd.toISOString(),
              label: format(cursor, "EEE MMM d • h:mm a"),
            });
          }
        }
        cursor = new Date(cursor.getTime() + 30 * 60 * 1000); // 30-min steps
      }
    }
    setSlots(result.slice(0, 40)); // limit for UI
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!selectedService || !selectedSlot) return;
    setSubmitting(true);

    try {
      // 1. Create pending booking
      const { data: booking, error } = await supabase
        .from("bookings")
        .insert({
          service_id: selectedService.id,
          dog_name: form.dog_name,
          customer_name: form.customer_name,
          customer_email: form.customer_email,
          customer_phone: form.customer_phone || null,
          start_time: selectedSlot.start,
          end_time: selectedSlot.end,
          status: "pending",
        })
        .select()
        .single();

      if (error || !booking) throw error || new Error("Failed to create booking");

      // 2. Create Stripe Checkout session
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          bookingId: booking.id,
          serviceName: selectedService.name,
          deposit: selectedService.deposit,
          customerEmail: form.customer_email,
        }),
      });

      const { url, error: checkoutError } = await res.json();
      if (checkoutError || !url) throw new Error(checkoutError || "Checkout failed");

      window.location.href = url;
    } catch (err: any) {
      alert(err.message || "Something went wrong");
      setSubmitting(false);
    }
  }

  if (loading) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-16 text-center">
        Loading services…
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-12">
      <h1 className="text-3xl font-bold">Book an Appointment</h1>
      <p className="mt-2 text-gray-600">Choose a service, pick a time, and pay a small deposit.</p>

      <form onSubmit={handleSubmit} className="mt-10 space-y-8">
        {/* Services */}
        <div>
          <h2 className="text-lg font-semibold">1. Select a service</h2>
          <div className="mt-3 grid gap-3">
            {services.map((s) => (
              <button
                key={s.id}
                type="button"
                onClick={() => {
                  setSelectedService(s);
                  setSelectedSlot(null);
                }}
                className={`flex items-start justify-between rounded-xl border p-4 text-left transition ${
                  selectedService?.id === s.id
                    ? "border-amber-600 bg-amber-50 ring-2 ring-amber-600"
                    : "hover:border-gray-400"
                }`}
              >
                <div>
                  <div className="font-medium">{s.name}</div>
                  <div className="text-sm text-gray-600">{s.description}</div>
                  <div className="mt-1 text-sm text-gray-500">{s.duration_min} min</div>
                </div>
                <div className="text-right">
                  <div className="font-semibold">{formatCurrency(s.price)}</div>
                  <div className="text-xs text-gray-500">
                    Deposit {formatCurrency(s.deposit)}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Time slots */}
        {selectedService && (
          <div>
            <h2 className="text-lg font-semibold">2. Pick a time</h2>
            {slots.length === 0 ? (
              <p className="mt-3 text-sm text-gray-500">No available slots in the next 14 days.</p>
            ) : (
              <div className="mt-3 grid max-h-64 grid-cols-2 gap-2 overflow-y-auto sm:grid-cols-3">
                {slots.map((slot) => (
                  <button
                    key={slot.start}
                    type="button"
                    onClick={() => setSelectedSlot(slot)}
                    className={`rounded-lg border px-3 py-2 text-sm transition ${
                      selectedSlot?.start === slot.start
                        ? "border-amber-600 bg-amber-50 font-medium"
                        : "hover:border-gray-400"
                    }`}
                  >
                    {slot.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Customer details */}
        {selectedSlot && (
          <div>
            <h2 className="text-lg font-semibold">3. Your details</h2>
            <div className="mt-3 grid gap-4 sm:grid-cols-2">
              <div>
                <label className="block text-sm font-medium">Your name</label>
                <input
                  required
                  className="mt-1 w-full rounded-lg border px-3 py-2"
                  value={form.customer_name}
                  onChange={(e) => setForm({ ...form, customer_name: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-sm font-medium">Dog&apos;s name</label>
                <input
                  required
                  className="mt-1 w-full rounded-lg border px-3 py-2"
                  value={form.dog_name}
                  onChange={(e) => setForm({ ...form, dog_name: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-sm font-medium">Email</label>
                <input
                  required
                  type="email"
                  className="mt-1 w-full rounded-lg border px-3 py-2"
                  value={form.customer_email}
                  onChange={(e) => setForm({ ...form, customer_email: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-sm font-medium">Phone (optional)</label>
                <input
                  type="tel"
                  className="mt-1 w-full rounded-lg border px-3 py-2"
                  value={form.customer_phone}
                  onChange={(e) => setForm({ ...form, customer_phone: e.target.value })}
                />
              </div>
            </div>
          </div>
        )}

        {selectedSlot && (
          <button
            type="submit"
            disabled={submitting}
            className="w-full rounded-full bg-amber-600 py-3 text-lg font-semibold text-white hover:bg-amber-700 disabled:opacity-60"
          >
            {submitting
              ? "Redirecting to payment…"
              : `Pay ${formatCurrency(selectedService!.deposit)} Deposit`}
          </button>
        )}
      </form>
    </div>
  );
}
