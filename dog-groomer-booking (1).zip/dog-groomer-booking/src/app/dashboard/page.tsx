"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { useAuth } from "@/lib/auth-client";
import { formatCurrency, formatDateTime } from "@/lib/utils";
import type { Booking, Service } from "@/types/database";
import { useRouter } from "next/navigation";
import Link from "next/link";

type BookingWithService = Booking & { services: Service | null };

export default function DashboardPage() {
  const { user, profile, loading: authLoading, isOwner, signOut } = useAuth();
  const supabase = createClient();
  const router = useRouter();
  const [bookings, setBookings] = useState<BookingWithService[]>([]);
  const [filter, setFilter] = useState<string>("all");
  const [loadingBookings, setLoadingBookings] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) {
      router.replace("/login?redirect=/dashboard");
    }
  }, [authLoading, user, router]);

  useEffect(() => {
    if (isOwner) {
      loadBookings();
    }
  }, [filter, isOwner]);

  async function loadBookings() {
    setLoadingBookings(true);
    let query = supabase
      .from("bookings")
      .select("*, services(*)")
      .order("start_time", { ascending: true });

    if (filter !== "all") {
      query = query.eq("status", filter);
    }

    const { data } = await query;
    setBookings((data as any) || []);
    setLoadingBookings(false);
  }

  async function updateStatus(id: string, status: string) {
    await supabase.from("bookings").update({ status }).eq("id", id);
    loadBookings();
  }

  // Still checking auth
  if (authLoading) {
    return (
      <div className="mx-auto max-w-5xl px-4 py-24 text-center text-gray-500">
        Checking access…
      </div>
    );
  }

  // Not logged in (middleware should catch this, but double-check)
  if (!user) {
    return null;
  }

  // Logged in but not an owner
  if (!isOwner) {
    return (
      <div className="mx-auto max-w-lg px-4 py-24 text-center">
        <div className="text-5xl">🔒</div>
        <h1 className="mt-6 text-2xl font-bold">Access Denied</h1>
        <p className="mt-3 text-gray-600">
          This page is only available to the salon owner.
        </p>
        <p className="mt-2 text-sm text-gray-500">
          Your current role is{" "}
          <code className="rounded bg-gray-100 px-1.5 py-0.5">
            {profile?.role || "unknown"}
          </code>
          .
          <br />
          Ask the owner to promote you, or run this in Supabase SQL:
        </p>
        <pre className="mt-4 overflow-x-auto rounded-lg bg-gray-100 p-3 text-left text-xs">
          {`update public.profiles\nset role = 'owner'\nwhere id = '${user.id}';`}
        </pre>
        <div className="mt-8 flex justify-center gap-4">
          <Link
            href="/"
            className="rounded-full border px-6 py-2.5 font-medium hover:bg-gray-50"
          >
            Go Home
          </Link>
          <button
            onClick={signOut}
            className="rounded-full bg-gray-800 px-6 py-2.5 font-medium text-white hover:bg-gray-900"
          >
            Sign out
          </button>
        </div>
      </div>
    );
  }

  // Authorized owner view
  return (
    <div className="mx-auto max-w-5xl px-4 py-12">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Owner Dashboard</h1>
          <p className="mt-1 text-sm text-gray-500">
            Signed in as {profile?.full_name || user.email}
            <span className="ml-2 rounded-full bg-amber-100 px-2 py-0.5 text-xs font-medium text-amber-800">
              owner
            </span>
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex gap-2">
            {["all", "pending", "paid", "completed", "cancelled"].map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`rounded-full px-4 py-1.5 text-sm font-medium capitalize ${
                  filter === f
                    ? "bg-amber-600 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                {f}
              </button>
            ))}
          </div>
          <button
            onClick={signOut}
            className="rounded-full border px-4 py-1.5 text-sm font-medium text-gray-600 hover:bg-gray-50"
          >
            Sign out
          </button>
        </div>
      </div>

      {loadingBookings ? (
        <p className="mt-16 text-center text-gray-500">Loading bookings…</p>
      ) : bookings.length === 0 ? (
        <p className="mt-16 text-center text-gray-500">No bookings found.</p>
      ) : (
        <div className="mt-8 overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="border-b text-gray-500">
              <tr>
                <th className="pb-3 pr-4">When</th>
                <th className="pb-3 pr-4">Customer / Dog</th>
                <th className="pb-3 pr-4">Service</th>
                <th className="pb-3 pr-4">Status</th>
                <th className="pb-3 pr-4">Paid</th>
                <th className="pb-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {bookings.map((b) => (
                <tr key={b.id} className="border-b last:border-0">
                  <td className="whitespace-nowrap py-4 pr-4">
                    {formatDateTime(b.start_time)}
                  </td>
                  <td className="py-4 pr-4">
                    <div className="font-medium">{b.customer_name}</div>
                    <div className="text-gray-500">{b.dog_name}</div>
                    <div className="text-xs text-gray-400">{b.customer_email}</div>
                    {b.customer_phone && (
                      <div className="text-xs text-gray-400">{b.customer_phone}</div>
                    )}
                  </td>
                  <td className="py-4 pr-4">{b.services?.name}</td>
                  <td className="py-4 pr-4">
                    <span
                      className={`rounded-full px-2.5 py-0.5 text-xs font-medium capitalize ${
                        b.status === "paid"
                          ? "bg-green-100 text-green-800"
                          : b.status === "completed"
                          ? "bg-blue-100 text-blue-800"
                          : b.status === "cancelled"
                          ? "bg-red-100 text-red-800"
                          : "bg-yellow-100 text-yellow-800"
                      }`}
                    >
                      {b.status}
                    </span>
                  </td>
                  <td className="py-4 pr-4">
                    {b.amount_paid ? formatCurrency(b.amount_paid) : "—"}
                  </td>
                  <td className="py-4">
                    <div className="flex gap-2">
                      {b.status !== "completed" && b.status !== "cancelled" && (
                        <button
                          onClick={() => updateStatus(b.id, "completed")}
                          className="text-xs font-medium text-blue-600 hover:underline"
                        >
                          Complete
                        </button>
                      )}
                      {b.status !== "cancelled" && (
                        <button
                          onClick={() => updateStatus(b.id, "cancelled")}
                          className="text-xs font-medium text-red-600 hover:underline"
                        >
                          Cancel
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
