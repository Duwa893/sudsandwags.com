-- Dog Groomer Booking App - Full Schema + RLS
-- Run this entire script in the Supabase SQL Editor

create extension if not exists "uuid-ossp";

-- SERVICES
create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  duration_min integer not null check (duration_min > 0),
  price integer not null check (price >= 0),
  deposit integer not null default 2500 check (deposit >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

-- AVAILABILITY RULES
create table if not exists public.availability_rules (
  id uuid primary key default gen_random_uuid(),
  day_of_week integer not null check (day_of_week between 0 and 6),
  start_time time not null,
  end_time time not null,
  active boolean not null default true
);

-- PROFILES
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  role text not null default 'customer' check (role in ('customer', 'owner')),
  created_at timestamptz not null default now()
);

-- BOOKINGS
create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid references auth.users(id) on delete set null,
  service_id uuid not null references public.services(id),
  dog_name text not null,
  customer_name text not null,
  customer_email text not null,
  customer_phone text,
  start_time timestamptz not null,
  end_time timestamptz not null,
  status text not null default 'pending' check (status in ('pending', 'paid', 'completed', 'cancelled')),
  stripe_session_id text,
  amount_paid integer,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists bookings_start_time_idx on public.bookings (start_time);
create index if not exists bookings_customer_id_idx on public.bookings (customer_id);
create index if not exists bookings_status_idx on public.bookings (status);

create or replace function public.handle_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists bookings_updated_at on public.bookings;
create trigger bookings_updated_at
  before update on public.bookings
  for each row execute procedure public.handle_updated_at();

create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', new.email), 'customer');
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- RLS
alter table public.services enable row level security;
alter table public.availability_rules enable row level security;
alter table public.bookings enable row level security;
alter table public.profiles enable row level security;

create policy "Public can view active services" on public.services for select using (active = true);
create policy "Owner can manage services" on public.services for all using (
  exists (select 1 from public.profiles where id = auth.uid() and role = 'owner')
);

create policy "Public can view availability" on public.availability_rules for select using (active = true);
create policy "Owner can manage availability" on public.availability_rules for all using (
  exists (select 1 from public.profiles where id = auth.uid() and role = 'owner')
);

create policy "Customers can view own bookings" on public.bookings for select using (
  customer_id = auth.uid() or exists (select 1 from public.profiles where id = auth.uid() and role = 'owner')
);
create policy "Anyone can create a booking" on public.bookings for insert with check (true);
create policy "Customers and owner can update bookings" on public.bookings for update using (
  customer_id = auth.uid() or exists (select 1 from public.profiles where id = auth.uid() and role = 'owner')
);

create policy "Users can view own profile" on public.profiles for select using (
  id = auth.uid() or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'owner')
);
create policy "Users can update own profile" on public.profiles for update using (id = auth.uid());

-- Seed data
insert into public.services (name, description, duration_min, price, deposit) values
  ('Basic Bath & Brush', 'Wash, dry, and brush for a clean pup', 60, 4500, 2500),
  ('Full Groom', 'Bath, haircut, nail trim, ear cleaning', 90, 7500, 2500),
  ('Nail Trim Only', 'Quick nail trim session', 20, 2000, 1000),
  ('Puppy Intro Groom', 'Gentle first-time grooming for puppies', 45, 4000, 2500);

insert into public.availability_rules (day_of_week, start_time, end_time) values
  (1, '09:00', '17:00'),
  (2, '09:00', '17:00'),
  (3, '09:00', '17:00'),
  (4, '09:00', '17:00'),
  (5, '09:00', '17:00'),
  (6, '10:00', '14:00');
