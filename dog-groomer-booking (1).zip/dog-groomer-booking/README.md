# Paws & Polish – Dog Groomer Booking App

A complete Next.js booking app with **Supabase + Stripe + Role-Based Access Control**.

## Features

- Public booking page with real availability slots
- $25 (or custom) deposit via Stripe Checkout
- Stripe webhook marks bookings as paid
- Customer lookup by email + magic-link login
- **Role-Based Access Control (RBAC)**
  - `customer` – default role
  - `owner` – full dashboard access
- Owner dashboard (protected by middleware + role check)
- Full Row Level Security in Supabase

## Quick Start

### 1. Install

```bash
cd dog-groomer-booking
npm install
```

### 2. Supabase setup

1. Create a free project at https://supabase.com
2. Go to SQL Editor → paste and run the entire contents of `supabase/schema.sql`
3. Copy Project URL + anon key + service_role key into `.env.local`

### 3. Stripe setup

1. Create account at https://stripe.com → stay in **Test mode**
2. Developers → API keys → copy Publishable + Secret keys
3. Developers → Webhooks → Add endpoint for `checkout.session.completed`
4. Copy the signing secret

### 4. Environment

```bash
cp .env.local.example .env.local
# fill in all values
```

### 5. Run locally

```bash
npm run dev
```

Open http://localhost:3000

### 6. Make yourself the owner (RBAC)

After signing up once via magic link:

1. Go to Supabase → Authentication → Users → copy your UUID
2. Run in SQL Editor:

```sql
update public.profiles
set role = 'owner'
where id = 'your-user-uuid';
```

3. Refresh the site. You will now see the **Owner Dashboard** link in the nav.

## Role-Based Access Control

| Role       | Can book | See own bookings | Owner dashboard | Manage all bookings |
|------------|----------|------------------|-----------------|---------------------|
| customer   | ✅       | ✅               | ❌              | ❌                  |
| owner      | ✅       | ✅               | ✅              | ✅                  |

### How it works

**Server-side helpers** (`src/lib/auth.ts`):
```ts
await requireAuth();           // must be logged in
await requireRole("owner");    // must be owner
await isOwner();               // boolean check
```

**Client-side hook** (`src/lib/auth-client.ts`):
```ts
const { user, profile, isOwner, isAuthenticated, signOut } = useAuth();
```

**Middleware** protects `/dashboard` (redirects to login if not authenticated).

**Page-level check** shows a clear “Access Denied” screen if the user is logged in but not an owner.

**Database RLS** already enforces the same rules at the Postgres level.

### Example protected API route

`GET /api/owner/bookings` – only owners can call it.  
See `src/app/api/owner/bookings/route.ts` for the pattern.

## Project structure

```
src/
  app/
    page.tsx                 → Home
    book/page.tsx            → Booking flow
    success/page.tsx         → After payment
    my-bookings/page.tsx     → Customer lookup
    dashboard/page.tsx       → Owner view (RBAC protected)
    login/page.tsx           → Magic link
    api/checkout/            → Create Stripe session
    api/webhooks/stripe/     → Payment confirmation
    api/owner/bookings/      → Example RBAC-protected API
  components/
    Nav.tsx                  → Role-aware navigation
  lib/
    auth.ts                  → Server-side RBAC helpers
    auth-client.ts           → Client-side useAuth hook
    supabase/                → Client helpers
    stripe.ts
    utils.ts
  middleware.ts              → Protects /dashboard
  types/database.ts
supabase/schema.sql          → Full DB + RLS + seed data
```

## Test payment

Stripe test card: `4242 4242 4242 4242` · any future expiry · any CVC.

## Deploy to Vercel

1. Push to GitHub
2. Import in Vercel
3. Add the same environment variables
4. Update Stripe webhook URL to your production domain
5. Set `NEXT_PUBLIC_APP_URL` to your live URL

## Next possible improvements

- Customer cancel button on My Bookings
- Twilio SMS reminder the day before
- Better calendar-style availability UI
- Owner can promote/demote other users from the dashboard

Enjoy!

## Customer Cancel Booking

Customers can cancel upcoming **pending** or **paid** appointments from the My Bookings page.

- Only future bookings can be cancelled
- Already completed or cancelled bookings cannot be cancelled
- Deposits are treated as non-refundable (message shown on confirm)
- Uses a secure API route (`/api/bookings/cancel`) that verifies the email matches the booking
